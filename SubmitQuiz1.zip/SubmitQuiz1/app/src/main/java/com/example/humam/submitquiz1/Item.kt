package com.example.humam.submitquiz1

data class Item (val name: String?, val image: Int?, val detail: String?)